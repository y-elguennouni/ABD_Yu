package es.ucm.abd.crossword;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import es.ucm.abd.crossword.Operator;
import es.ucm.abd.crossword.QueryCondition;


//import org.apache.commons.lang3.StringUtils;





public abstract class AbstractMapper<T, K> {

	protected DataSource ds;

	/**
	 * @return te dice si la tabla tiene auto increment
	 */
	protected abstract boolean isAI();

	/**
	 * @param le metes un objeto
	 * @return el ojeto en un array ordenado segun las columnas
	 */
	protected abstract Object[] serializeObject(T objeto);

	/**
	 * @param la clave de la tabla, ya sea una cosa o una clase
	 * @return un array con la clave en el orden correcto
	 */
	protected abstract Object[] serializeKey(K clave);

	/** 
	 * @return la clave del mapper en concreto
	 */
	protected abstract K getKey(T objeto);
	
	/**
	 * @return el nombre de la tabla
	 */
	protected abstract String getTableName();

	/**
	 * @return las columnas
	 */
	protected abstract String[] getColumnNames();
	
	
	protected abstract String[] getKeyColumnNames();

	protected abstract T buildObject(ResultSet rs) throws SQLException;

	/** 
	 * @param El result set de la consulta, pero solo lleva las claves
	 * este m�todo lo sobrescriben las tablas con A_I	 
	 * @return La clase del mapper en concreto
	 * @throws SQLException
	 */
	protected T buildObjectFromKeys(ResultSet rs) throws SQLException{
		return null;
	}
	
	public AbstractMapper(DataSource ds) {
		this.ds = ds;
	}

	/**
	 * @param la clave primaria de cada tabla, que es la K,  * puede ser un string, un int... o una clase que contenga todo
	 * @return La clase del mapper en concreto
	 */
	@SuppressWarnings("unchecked")//esto es para el casting 
	public T findById(K clave) {
		T resultado = null;
		List<T> listaResultados=new ArrayList<T>();
		QueryCondition[] conditions=null;
		conditions=generaCondicionesId(clave);
		listaResultados=findByConditions(conditions);
		if (!listaResultados.isEmpty())
			resultado = (T) listaResultados.toArray()[0];//este casting genera el@SuppressWarnings("unchecked")
		return resultado;				
	}
	
	/**
	 * 
	 * @param La clave de cada tabla, sea una sola cosa o sea otra clase
	 * @return un array de Query conditions, con tantas condiciones como claves haya
	 */
	private QueryCondition[] generaCondicionesId (K key){
		String[] nombresPrimarios=getKeyColumnNames();
		Object[] valoresPrimarios=serializeKey(key);
		QueryCondition[] conditions= new QueryCondition[valoresPrimarios.length];
		for (int i=0;i<nombresPrimarios.length;i++){
			conditions[i]=new QueryCondition(nombresPrimarios[i],Operator.EQ,valoresPrimarios[i]);
		}
		return conditions;
	}

	protected QueryCondition[] generaCondicionesString (String valor){
		String[] nombresPrimarios=getColumnNames();
		QueryCondition[] conditions=new QueryCondition[nombresPrimarios.length];
		for (int i=0;i<nombresPrimarios.length;i++){
			conditions[i]=new QueryCondition(nombresPrimarios[i],Operator.LIKE,valor);
			//System.out.println(conditions[i].tostring());
		}
		return conditions;
	}
	/**
	 * busca en todas las columnas si hay algo parecido(usa un like)
	 * @param string a buscar
	 * @return una lista de filas de la tabla que corresponen a la columna
	 */
	public List<T> findByString(String string){	//se podria abstarer creando un metodo abstracto llamado get columnastring()
		List<T> listaResultados=new ArrayList<T>();
		QueryCondition[] conditions=generaCondicionesString(string);
		listaResultados=findByConditions(conditions);
		//elimino elementos repetidos de la lista
		List<T> listaResultadosFiltrada=new ArrayList<T>();
		for(int i=0;i<listaResultados.size();i++)
			if(!listaResultadosFiltrada.contains(listaResultados.get(i)))
				listaResultadosFiltrada.add(listaResultados.get(i));			
		return listaResultadosFiltrada;
	}
	/**
	 *al query le metes el nombre de la columna y su valor 
	 * @param conditions
	 * @return
	 */
	protected List<T> findByConditions(QueryCondition[] conditions) {
		Connection con        = null;
		PreparedStatement pst = null;
		ResultSet rs          = null;
		List<T> resultados = new ArrayList<T>();
		try {
			con = ds.getConnection();
			String cadenaWhere = generaCadenaWhere(conditions);
			//System.out.println(cadenaWhere);
			pst=con.prepareStatement("SELECT * FROM " + getTableName() + " WHERE (" + cadenaWhere + ")");
			for(int i=0;i<conditions.length;i++)								
				pst.setObject(i+1, conditions[i].getValue());				
			rs = pst.executeQuery();		
			while(rs.next()) 
				resultados.add((buildObject(rs)));						
		}			
		catch (SQLException e) {e.printStackTrace();} 
		finally {
			try {
				if (rs != null) rs.close();
				if (pst != null) pst.close();
				if (con != null) con.close();
			} catch (Exception e) {e.printStackTrace();}
		}
		return resultados;
	}
	
	private String generaCadenaWhere(QueryCondition[] conditions) {
		String cadenaWhere=conditions[0].getColumnName()+conditions[0].getOperator().toString()+"?";
		for (int i=1;i<conditions.length;i++) 
			cadenaWhere+=" AND " +conditions[i].getColumnName()+conditions[i].getOperator().toString()+"?";
		return cadenaWhere;
	}

	public T insert(T clase){
		Connection con = null;
		PreparedStatement pst=null;
		ResultSet rs        = null;
		T objeto =null;
		try{
			con=ds.getConnection();
			String[] ColumnNames = this.getColumnNames();
			String[] KeyColumnNames = this.getKeyColumnNames();
			if (isAI())  //si tiene columna autoincrement			
				for (int j=0;j<KeyColumnNames.length;j++)
					ColumnNames=ArrayUtils.removeElements(ColumnNames, KeyColumnNames[j]);			
			String columnNamesWithComas =StringUtils.join(ColumnNames,",");
			String interrogaciones="?";
			for (int i=0;i<ColumnNames.length-1;i++) 
				interrogaciones+=",?";
			pst=con.prepareStatement("INSERT INTO " + getTableName() + "(" + columnNamesWithComas 
					+") VALUES ("+ interrogaciones + ")",Statement.RETURN_GENERATED_KEYS);
			//Preparo lo que voy a meter en la consulta
			Object[] ColumnValues=serializeObject(clase);
			//si es autoincrement, tengo que filtrar columna de clave
			Object[] KeyColumnValues=serializeKey(getKey(clase));
			if (isAI())
				for (int i=0;i<KeyColumnValues.length;i++)
					ColumnValues=ArrayUtils.removeElements(ColumnValues, KeyColumnValues);
			for (int i=0;i<ColumnValues.length;i++)
				pst.setObject(i+1, ColumnValues[i]);
			if(1==pst.executeUpdate())	
				if(isAI()){
					rs=pst.getGeneratedKeys();
					rs.next();				
					objeto = buildObjectFromKeys(rs);
				}
				else 
					objeto = clase;

		} catch ( SQLException  e) {} //esto se borra
		finally {
			try {
				if (pst != null) pst.close();
				if (con != null) con.close();
				if (rs  != null) rs.close();

			} catch (Exception e) {e.printStackTrace();};
		}		
		return  objeto;
	}
	
	public boolean update(T object, K oldKey) {				
		Connection con = null;
		PreparedStatement pst=null;		
		boolean resultado=false;
		QueryCondition[] conditions=null;
		conditions=generaCondicionesId(oldKey);
		String cadenaWhere="";
		cadenaWhere=generaCadenaWhere(conditions);		
		try{			
			con=ds.getConnection();
			String[] ColumnNames = getColumnNames();
			Object[] ColumnValues=serializeObject(object);			
			String  cadenaNombresConComas="";
			cadenaNombresConComas+=ColumnNames[0]+"=?";
			for (int i=1;i<ColumnNames.length;i++)
				cadenaNombresConComas+=", "+ColumnNames[i]+"=?";
			pst=con.prepareStatement("UPDATE "+this.getTableName()+" SET " + cadenaNombresConComas + " WHERE " +"("+cadenaWhere+")");
			int i;		
			for (i=0;i<ColumnValues.length;i++)
				pst.setObject(i+1, ColumnValues[i]);
			Object[] valoresClave=serializeKey(oldKey);
			int tamClave=valoresClave.length;
			for(int j=0;j<tamClave;j++){
				pst.setObject(i+1, valoresClave[j]);
				i++;
			}

			int numFilas = pst.executeUpdate();
			if(numFilas==1)resultado=true;			
		} catch ( SQLException  e) {} finally {
			try {
				if (pst != null) pst.close();
				if (con != null) con.close();				
			} catch (Exception e) {			e.printStackTrace();
			};
		}	
		return resultado;
	}

	public boolean delete(T object){
		K key = getKey(object);
		Connection con = null;
		PreparedStatement pst=null;
		boolean resultado=false;
		QueryCondition[] conditions=null;
		conditions=generaCondicionesId(key);
		String cadenaWhere="";
		cadenaWhere=generaCadenaWhere(conditions);		
		try{			
			con=ds.getConnection();			
			Object[] KeyValues=serializeKey(key);
			int tamKey = KeyValues.length;	
			pst=con.prepareStatement("DELETE FROM "+this.getTableName()+ " WHERE " + "("+cadenaWhere+")");
			for (int i=0;i<tamKey;i++)
				pst.setObject(i+1, KeyValues[i]);					
			int numFilas = pst.executeUpdate();
			if(numFilas==1)resultado=true;
		} catch ( SQLException  e) {
			e.printStackTrace();
		} finally {
			try {
				if (pst != null) pst.close();
				if (con != null) con.close();				
			} catch (Exception e) { e.printStackTrace();};
		}	
		return resultado;
	}
	public List<T> getAll(){
		Connection con = null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		List<T> resultado=new ArrayList<T>();		
		try{			
			con=ds.getConnection();			
			pst=con.prepareStatement("SELECT * FROM "+this.getTableName());
			rs=pst.executeQuery();
			while(rs.next()) 
				resultado.add((buildObject(rs)));
		} catch ( SQLException  e) {
			e.printStackTrace();
		} finally {
			try {
				if (pst != null) pst.close();
				if (con != null) con.close();				
			} catch (Exception e) { e.printStackTrace();};
		}	
		return resultado;
	}
}