package es.ucm.abd.crossword;
import java.util.List;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class CrosswordDAO {
	private DataSource ds;

	/**
	 * Aquí se debe inicializar el pool de conexiones, mediante
	 * la creación de un DataSource, que deberá ser asignado a
	 * la variable ds.
	 */
	public CrosswordDAO() throws Exception { 
		
		ComboPooledDataSource cpds = new ComboPooledDataSource();
		cpds.setDriverClass("com.mysql.jdbc.Driver");
		cpds.setJdbcUrl("jdbc:mysql://localhost/practica1_506");
		cpds.setUser("UsuarioP1");
		cpds.setPassword("");
		
		cpds.setAcquireRetryAttempts(1);
		cpds.setAcquireRetryDelay(1);
		
		this.ds = cpds;
	}

	
	/**
	 * Devuelve la contraseña del usuario cuyo nick se pasa como
	 * parámetro. Devuelve null si el usuario no existe. 
	 */
	public String getPassword(String nick) {
		UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		Usuario javier = usuariomapper.findById(nick);
		
		if(javier!= null)
			return javier.getPass();
		else 
			return null;
	}
	
	/**
	 * Modifica la contraseña del usuario pasado como parámetro 
	 */
	public void modifyPassword(String nick, String newPassword) {
		UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		Usuario javier = usuariomapper.findById(nick);
		if (javier != null){
			Usuario usuarioProvisional  = new Usuario(nick, newPassword, javier.getAvatar(), javier.getFecha());
			usuariomapper.update(usuarioProvisional,javier.getNick());
		}
	}

	/**
	 * Devuelve una lista de las claves de aquellos crucigramas
	 * cuyo título contenga str.
	 * 
	 * Si escogisteis una clave numérica para la tabla de crucigramas,
	 * se debe devolver una lista de Integer. Si escogisteis el título
	 * como clave, se debe devolver una lista de String. Si, por el contrario,
	 * escogisteis una clave compuesta, debéis crear una clase para almacenar
	 * los atributos de dicha clave. 
	 */
	public List<Integer> findCrosswordsByTitle(String str) {
		CrucigramaMapper crucimapper = new CrucigramaMapper(ds);
		List<Integer> crucigramas = crucimapper.findByTitle(str);
		return crucigramas;
	}

	/**
	 * Devuelve el título del crucigrama cuya clave se pasa como
	 * parámetro.
	 */
	public String getCrosswordTitle(Object id) {
		CrucigramaMapper correoMapper = new CrucigramaMapper(ds);
		Crucigrama cruci = correoMapper.findById((Integer) id);
		if(cruci!=null)
			return cruci.getTitulo();
		else 
			return null;
	}
	
	/**
	 * Añade un crucigrama a la lista de crucigramas activos de un usuario.
	 * 
	 * El crucigrama se especifica mediante su clave
	 */
	public void addCrosswordToUser(String nick, Object crosswordId) {
		CrucigramaMapper cruciMapper = new CrucigramaMapper(ds);
		UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		ActivaCrucigramaMapper activo = new ActivaCrucigramaMapper(ds);
		int id = (int) crosswordId;
		Crucigrama crucigrama = cruciMapper.findById(id);
		Usuario user = usuariomapper.findById(nick);
		if((crucigrama != null) && (user != null)){
			ActivaCrucigrama activa = new ActivaCrucigrama(id, nick);
			ActivaCrucigrama activaprovisional = activo.findById(activa);
			if (activaprovisional == null)
				activo.insert(activa);
			
		}
	}
	
	/**
	 * Devuelve la lista de identificadores de los crucigramas activos
	 * del usuario pasado como parámetro
	 */
	public List<Integer> getCrosswordsOf(String nick) {
		ActivaCrucigramaMapper activo = new ActivaCrucigramaMapper(ds);
		List<Integer> crucigramas = activo.findByUser(nick);
		return crucigramas;
	}

	/**
	 * Cierra el dataSource
	 */
	public void close() {
		((ComboPooledDataSource)ds).close();
	}
}
