package es.ucm.abd.crossword;

public class ActivaCrucigrama {
	private int crucigrama;
	private String usuario;

	
	public ActivaCrucigrama(int crucigrama,String usuario) {
		this.crucigrama = crucigrama;
		this.usuario = usuario;
	}

	public int getCrucigrama() {
		return crucigrama;
	}

	public void setCrucigrama(int crucigrama) {
		this.crucigrama = crucigrama;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String toString(){
		return "usuario :"+ usuario + "-> crucigrama"+crucigrama;
	}
}
