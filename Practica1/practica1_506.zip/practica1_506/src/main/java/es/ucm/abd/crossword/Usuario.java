package es.ucm.abd.crossword;

import java.sql.Date;

public class Usuario {
		private String nick ;
		private String pass;
		private byte[] avatar;
		private Date fecha;
		
	public Usuario(String nick, String pass,byte[] avatar,Date fecha) {
		this.nick = nick;
		this.pass = pass;
		this.avatar = avatar;
		this.fecha = fecha;
	}
	
	public String getNick(){
		return nick;
	}
	public void setNick(String nick){
		this.nick = nick;
	}
	
	public String getPass(){
		return pass;
	}
	public void setPass(String pass){
		this.pass = pass;
	}
	
	public byte[] getAvatar(){
		return avatar;
	}
	public void setAvatar(byte[] avatar){
		this.avatar = avatar; 
	}
	public Date getFecha(){
		return fecha;
	}
	public void setFecha(Date fecha){
		this.fecha = fecha;
	}
	
	public String toString(){
		return "Usuario [nick= " + nick + ", pass= " + pass + "]";	
		
	}

}
