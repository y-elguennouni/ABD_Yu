package es.ucm.abd.crossword;

import java.sql.Blob;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;



public class UsuarioMapper extends AbstractMapper<Usuario, String>  {
	private static final String[] KEY_COLUMN_NAME = new String[] {"nick"};
	private static final String[] COLUMN_NAMES = new String[] {"nick","pass","Imagen","Fecha_naci"};
	private static final String TABLE_NAME = "Usuario";
	private static final boolean AUTO_INCREMENT = false;
	public UsuarioMapper(DataSource ds) {
		// TODO Auto-generated constructor stub
		super(ds);
	}

	@Override
	protected boolean isAI() {
		// TODO Auto-generated method stub
		return AUTO_INCREMENT;
	}

	@Override
	protected Object[] serializeObject(Usuario objeto) {
		// TODO Auto-generated method stub
		return new Object[]{objeto.getNick(),objeto.getPass(),objeto.getAvatar(),objeto.getFecha()};
	}

	@Override
	protected Object[] serializeKey(String clave) {
		// TODO Auto-generated method stub
		return new Object[] {clave};
	}

	@Override
	protected String getKey(Usuario objeto) {
		// TODO Auto-generated method stub
		return objeto.getNick();
	}

	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}

	@Override
	protected String[] getColumnNames() {
		return COLUMN_NAMES;
	}

	@Override
	protected String[] getKeyColumnNames() {
		return KEY_COLUMN_NAME;
	}

	@Override
	protected Usuario buildObject(ResultSet rs) throws SQLException {
		Usuario result;
		String nick  = rs.getString("nick");
		String pass  = rs.getString("pass");
		Date fecha = rs.getDate("Fecha_naci");
		Blob fotoBlob    = rs.getBlob("imagen");
		byte[] fotoByte = null;
		if(fotoBlob != null){
			fotoByte = fotoBlob.getBytes(1, (int)fotoBlob.length());
		
		}
		result = new Usuario(nick,pass,fotoByte,fecha);
		return result;
	}
	
}
