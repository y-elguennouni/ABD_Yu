package es.ucm.abd.crossword;

/**
 * Representa un operador de comparación. Se utiliza en QueryCondition.
 */
public enum Operator {
	EQ(" = "), LE(" <= "), LT(" < "), GE(" >= "), GT(" > "), NEQ(" != "), LIKE(" LIKE ");
	
	private String representacion;//lleva los espacios incluidos
	
	private Operator(String representacion ) {
		this.representacion = representacion;
	}
	
	/*
	 * Sería conveniente añadir un atributo a cada enum con la representación
	 * de cada operador (en forma de cadena)
	 */
	
	@Override
	public String toString() {
		return representacion;
	}
}
