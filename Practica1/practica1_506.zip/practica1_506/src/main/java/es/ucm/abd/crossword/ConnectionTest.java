package es.ucm.abd.crossword;




import java.util.List;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ConnectionTest {
	public static void main(String[] args) throws Exception {
		ComboPooledDataSource cpds = new ComboPooledDataSource();
		cpds.setDriverClass("com.mysql.jdbc.Driver");
		cpds.setJdbcUrl("jdbc:mysql://localhost/practica1_506");
		cpds.setUser("UsuarioP1");
		cpds.setPassword("");
		
		cpds.setAcquireRetryAttempts(1);
		cpds.setAcquireRetryDelay(1);
		
		DataSource ds = cpds;
		
		
		/*PalabraMapper palabramapper = new PalabraMapper(ds);
		Palabra javier = palabramapper.findById(3);
		System.out.println(javier);
		javier= new Palabra("hola", "conche", null);
		palabramapper.insert(javier);
		javier= new Palabra(21,"Si", "Funciona", null);
		palabramapper.delete(palabramapper.findById(21));*/
		
		/*1UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		String nick = "user2";
		Usuario javier = usuariomapper.findById(nick);
		if(javier!= null)
		System.out.println(javier.getPass());
		else System.out.println("null");*/
		
		/*2UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		String newPass = "hola2";
		String nick = "user2";
		String nick2= "user3";
		Usuario javier = usuariomapper.findById(nick2);
		if (javier != null){
			Usuario usuarioProvisional  = new Usuario(nick2, newPass, javier.getAvatar(), javier.getFecha());
			System.out.println(usuarioProvisional);
			usuariomapper.update(usuarioProvisional,javier.getNick());
		}*/
		CrucigramaMapper crucimapper = new CrucigramaMapper(ds);
		String nomb = "ruci";
		List<Integer> crucigramas = crucimapper.findByTitle(nomb);
		//System.out.println(crucigramas.size());
		for(int i=0;i<crucigramas.size();i++)
			System.out.println(crucigramas.get(i));
		
		
		/*4CrucigramaMapper correoMapper = new CrucigramaMapper(ds);
		Crucigrama correo = correoMapper.findById(2);
		if(correo!=null)
			System.out.println(correo.getTitulo());*/
		/*String nick = "user";
		int idCrucigrama = 2;
		CrucigramaMapper correoMapper = new CrucigramaMapper(ds);
		UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		ActivaCrucigramaMapper activo = new ActivaCrucigramaMapper(ds);
		Crucigrama crucigrama = correoMapper.findById(idCrucigrama);
		Usuario user = usuariomapper.findById(nick);
		if((crucigrama != null) && (user != null)){
			ActivaCrucigrama activa = new ActivaCrucigrama(idCrucigrama, nick);
			ActivaCrucigrama activaprovisional = activo.findById(activa);
			if (activaprovisional == null)
				activo.insert(activa);
			
		}*/
		/*String nick = "user4";
		//UsuarioMapper usuariomapper = new UsuarioMapper(ds);
		ActivaCrucigramaMapper activo = new ActivaCrucigramaMapper(ds);
		List<Integer> crucigramas = activo.findByUser(nick);
		for(int i=0;i<crucigramas.size();i++)
			System.out.println(crucigramas.get(i));*/
		cpds.close();
	}
}
