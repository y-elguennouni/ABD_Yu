package es.ucm.abd.crossword;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;





public class PalabraMapper extends AbstractMapper<Palabra, Integer> {
	private static final String[] KEY_COLUMN_NAME = new String[] {"id"};
	private static final String[] COLUMN_NAMES = new String[] {"id","Enunciado","Contenido","Pista"};
	private static final String TABLE_NAME = "palabra";
	private static final boolean AUTO_INCREMENT = true;

	public PalabraMapper(DataSource ds) {
		super(ds);
	}

	@Override
	protected boolean isAI() {
		// TODO Auto-generated method stub
		return AUTO_INCREMENT;
	}

	@Override
	protected Object[] serializeObject(Palabra objeto) {
		return new Object[]{objeto.getId(),objeto.getEnunciado(),objeto.getContenido(),objeto.getPista()};
	}

	@Override
	protected Object[] serializeKey(Integer clave) {
		return new Object[] {clave};
	}

	@Override
	protected Integer getKey(Palabra objeto) {
		return objeto.getId();
	}

	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}

	@Override
	protected String[] getColumnNames() {
		return COLUMN_NAMES;
	}

	@Override
	protected String[] getKeyColumnNames() {
		return KEY_COLUMN_NAME;
	}

	@Override
	protected Palabra buildObject(ResultSet rs) throws SQLException {
		Palabra result;
		int id  = rs.getInt("id");
		String enunciado      = rs.getString("enunciado");
		String contenido =rs.getString("contenido");
		Blob fotoBlob    = rs.getBlob("Pista");
		byte[] fotoByte = null;
		if(fotoBlob != null){
			fotoByte = fotoBlob.getBytes(1, (int)fotoBlob.length());

		/*InputStream is = fotoBlob.getBinaryStream();
	
		try {
			fotoByte = IOUtils.toByteArray(is);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		}
		result = new Palabra(id,enunciado,contenido,fotoByte);
		return result;
		/*
		 * Blob blob=null; //is our blob object 
			byte[] buffer; //is our byte array
			blob=new SerialBlob(buffer)
		 * 
		 */
		 
	}

}
