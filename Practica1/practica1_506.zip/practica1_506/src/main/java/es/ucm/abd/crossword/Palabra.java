package es.ucm.abd.crossword;


public class Palabra {
	private Integer id;
	private String enunciado;
	private String contenido;
	private byte[] pista;
	
	public Palabra(Integer id, String enunciado, String contenido, byte[] foto) {
		this.id = id;
		this.enunciado = enunciado;
		this.contenido = contenido;
		this.pista = foto;
	}
	
	public Palabra( String enunciado, String contenido, byte[] foto) {
		this.enunciado = enunciado;
		this.contenido = contenido;
		this.pista = foto;
	}
	
	public String getEnunciado() {
		return enunciado;
	}

	public void setEnunciado(String enunciado) {
		this.enunciado = enunciado;
	}
	
	public String getContenido() {
		return contenido;
	}

	public void setContenido(String enunciado) {
		this.enunciado = enunciado;
	}
	public byte[] getPista() {
		return pista;
	}

	public void setPista(byte[] pista) {
		this.pista = pista;
	}
	
	public Integer getId(){
		return id;
	}
	
	public String toString(){
	return "Palabra [IdPalabra= " + id + ", enunciado= " + enunciado
	+ ", contenido=" + contenido + "]";	
		
	}
	
}
