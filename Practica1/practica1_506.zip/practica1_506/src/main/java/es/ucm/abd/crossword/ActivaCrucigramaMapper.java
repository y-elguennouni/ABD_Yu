package es.ucm.abd.crossword;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;



public class ActivaCrucigramaMapper extends AbstractMapper<ActivaCrucigrama, ActivaCrucigrama> {
	private static final String[] KEY_COLUMN_NAME = new String[] {"C_id","U_nick"};
	private static final String[] COLUMN_NAMES = new String[] {"C_id","U_nick"};
	private static final String TABLE_NAME = "u_activo_c";
	private static final boolean AUTO_INCREMENT = false;

	public ActivaCrucigramaMapper(DataSource ds) {
		super(ds);
	}

	@Override
	protected boolean isAI() {
		// TODO Auto-generated method stub
		return AUTO_INCREMENT;
	}

	@Override
	protected Object[] serializeObject(ActivaCrucigrama objeto) {
		return new Object[]{objeto.getCrucigrama(),objeto.getUsuario()};
	}

	@Override
	protected Object[] serializeKey(ActivaCrucigrama clave) {
		return new Object[] {clave.getCrucigrama(),clave.getUsuario()};
	}

	@Override
	protected ActivaCrucigrama getKey(ActivaCrucigrama objeto) {
		
		return new ActivaCrucigrama(objeto.getCrucigrama(), objeto.getUsuario());
	}

	@Override
	protected String getTableName() {
		return TABLE_NAME;
	}

	@Override
	protected String[] getColumnNames() {
		// TODO Auto-generated method stub
		return COLUMN_NAMES;
	}

	@Override
	protected String[] getKeyColumnNames() {
		// TODO Auto-generated method stub
		return KEY_COLUMN_NAME;
	}

	@Override
	protected ActivaCrucigrama buildObject(ResultSet rs) throws SQLException {
		ActivaCrucigrama result;
		int c_id  = rs.getInt("C_id");
		String Usuario  = rs.getString("U_nick");
		result = new ActivaCrucigrama(c_id, Usuario);
		return result;
	}
	public List<Integer> findByUser(String usuario){
		List<Integer> result = new ArrayList<Integer>();
		List<ActivaCrucigrama> listaResultados = new ArrayList<ActivaCrucigrama>();
		QueryCondition[] conditions=new QueryCondition[1];
		conditions[0]=new QueryCondition("U_nick",Operator.LIKE,usuario);
		listaResultados=findByConditions(conditions);
		for(int i=0;i<listaResultados.size();i++)
			if(!result.contains(listaResultados.get(i).getCrucigrama()))
				result.add(listaResultados.get(i).getCrucigrama());
		return result;
	}

}
