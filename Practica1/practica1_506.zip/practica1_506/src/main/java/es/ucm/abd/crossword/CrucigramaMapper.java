package es.ucm.abd.crossword;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;



public class CrucigramaMapper extends AbstractMapper<Crucigrama, Integer> {
	
	private static final String[] KEY_COLUMN_NAME = new String[] {"id"};
	private static final String[] COLUMN_NAMES = new String[] {"id","Titulo","Fecha"};
	private static final String TABLE_NAME = "crucigrama";
	private static final boolean AUTO_INCREMENT = true;

	public CrucigramaMapper(DataSource ds) {
		// TODO Auto-generated constructor stub
		super(ds);
	}

	@Override
	protected boolean isAI() {
		// TODO Auto-generated method stub
		return AUTO_INCREMENT;
	}

	@Override
	protected Object[] serializeObject(Crucigrama objeto) {
		// TODO Auto-generated method stub
		return  new Object[]{objeto.getId(),objeto.getTitulo(),objeto.getFecha()};
	}

	@Override
	protected Object[] serializeKey(Integer clave) {
		return new Object[] {clave};
	}

	@Override
	protected Integer getKey(Crucigrama objeto) {
		return objeto.getId();
	}

	@Override
	protected String getTableName() {
		// TODO Auto-generated method stub
		return TABLE_NAME;
	}

	@Override
	protected String[] getColumnNames() {
		// TODO Auto-generated method stub
		return COLUMN_NAMES;
	}

	@Override
	protected String[] getKeyColumnNames() {
		return KEY_COLUMN_NAME;
	}

	@Override
	protected Crucigrama buildObject(ResultSet rs) throws SQLException {
		Crucigrama result;
		int id  = rs.getInt("id");
		String Titulo  = rs.getString("titulo");
		Date Fecha = rs.getDate("Fecha");
		result = new Crucigrama(id,Titulo,Fecha);
		return result;
	}
	public List<Integer> findByTitle(String string){
		List<Integer> result = new ArrayList<Integer>();
		List<Crucigrama> listaResultados=new ArrayList<Crucigrama>();
		QueryCondition[] conditions=new QueryCondition[1];
			conditions[0]=new QueryCondition("Titulo",Operator.LIKE,"%"+string+"%");
		listaResultados=findByConditions(conditions);
		//elimino elementos repetidos de la lista
		//List<Crucigrama> listaResultadosFiltrada=new ArrayList<Crucigrama>();
		for(int i=0;i<listaResultados.size();i++)
			if(!result.contains(listaResultados.get(i).getId()))
				result.add(listaResultados.get(i).getId());			
		return result;
	
		
		}

}
