package es.ucm.abd.crossword;

public class Etiqueta {
	private Integer id;
	private String titulo;

	public Etiqueta(Integer id, String titulo) {
		this.id = id;
		this.titulo = titulo;
	}
	
	public Integer getId(){
		return id;
	}
	public void setId(Integer id){
		this.id = id;
	}
	
	public String getTitulo(){
		return titulo;
	}
	public void setTitulo(String titulo){
		this.titulo = titulo;
	}

}
